<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Error
$_['error_extension'] = 'Uyarı: Ödeme metotu eklentisi bulunamadı!';
$_['error_recurring'] = 'Uyarı: Ödeme metotunda yinelenen ödeme yoktur!';
$_['error_payment']   = 'Uyarı: %s ödeme yöntemi bulunamadı!';