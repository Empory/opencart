<?php
// Heading
$_['heading_title']     = 'Başlangıç';

// Text
$_['text_success']      = 'Başarılı: Başlangıç başarılı bir şekilde değiştirildi!';
$_['text_list']         = 'Başlangıç Listesi';

// Column
$_['column_code']       = 'Başlangıç Kodu';
$_['column_sort_order'] = 'Sıralama';
$_['column_action']     = 'Eylem';

// Error
$_['error_permission']  = 'Uyarı: Başlangıçları düzenleme iznine sahip değilsiniz!';