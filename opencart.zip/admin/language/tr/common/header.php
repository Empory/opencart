<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title']          = 'OpenCart Türkçe';

// Text
$_['text_notification']      = 'Bildirimler';
$_['text_notification_all']  = 'Hepsini Göster';
$_['text_notification_none'] = 'Hiç bildirim yok';
$_['text_profile']           = 'Profilim';
$_['text_store']             = 'Mağazalar';
$_['text_help']              = 'Yardım';
$_['text_homepage']          = 'OpenCart Anasayfa';
$_['text_support']           = 'Forum Destek';
$_['text_documentation']     = 'Dökümantasyon';
$_['text_logout']            = 'Çıkış Yap';