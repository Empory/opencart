<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_footer']  = 'Altyapı: <a href="https://www.opencart.com">OpenCart</a> Türkçe Çeviri: <a href="https://e-piksel.com" title="E-Piksel E-Ticaret ve Bilgi Teknolojileri">E-Piksel</a> &copy; 2009 - ' . date('Y') . ' Tüm Hakları Saklıdır.';
$_['text_version'] = 'Sürüm %s';