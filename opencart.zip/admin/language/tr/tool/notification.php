<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title']    = 'Bildirimler';

// Text
$_['text_success']     = 'Başarılı: Bildirimler başarılı bir şekilde değiştirildi!';
$_['text_list']        = 'Bildirim Listesi';

// Column
$_['column_message']   = 'Mesaj';
$_['column_action']    = 'Eylem';

// Error
$_['error_permission'] = 'Uyarı: Bildirimleri düzenleme iznine sahip değilsiniz!';