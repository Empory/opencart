<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_subject'] = '%s - GDPR İsteğiniz Onaylandı!';
$_['text_request'] = 'Hesap Silme İsteği';
$_['text_hello']   = 'Merhaba <strong>%s</strong>,';
$_['text_user']    = 'Kullanıcı';
$_['text_gdpr']    = 'GDPR veri silme isteğiniz onaylandı ve <strong>%s Gün</strong> içinde silinecektir.';
$_['text_q']       = 'Soru: Verilerinizi neden hemen silmiyoruz?';
$_['text_a']       = 'Cevap: Hesap silme istekleri, herhangi bir sahtekarlık tespiti, ters ibrazlar veya geri ödeme işlemeleri için <strong>%s günden</strong> sonra işlenecektir.';
$_['text_delete']  = 'Hesabınız silindiğinde sizi bilgilendiren bir e-posta alacaksınız.';
$_['text_thanks']  = 'Teşekkürler,';