<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_subject']   = '%s - Hesabınız Reddedildi!';
$_['text_welcome']   = '%s sitemize kayıt olduğunuz için teşekkür ederiz!';
$_['text_denied']    = 'Maalesef isteğiniz reddedildi. Daha fazla bilgi için iletişime geçebilirsiniz:';
$_['text_thanks']    = 'Teşekkürler,';

// Button
$_['button_contact'] = 'İletişim';