<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_subject'] = '%s - Ortaklık Hesabınız Reddedildi!';
$_['text_welcome'] = '%s ortaklık programına kayıt olduğunuz için teşekkür ederiz!';
$_['text_denied']  = 'Maalesef isteğiniz reddedildi. Daha fazla bilgi için iletişime geçebilirsiniz:';
$_['text_thanks']  = 'Teşekküler,';