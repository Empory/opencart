<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_subject']       = '%s - İade Durum Güncellemesi %s';
$_['text_return_id']     = 'İade No:';
$_['text_date_added']    = 'İade Ekleme Tarihi:';
$_['text_return_status'] = 'Ürün iade isteğiniz aşağıdaki duruma güncellendi:';
$_['text_comment']       = 'İade isteğiniz için yapılan açıklamalar:';
$_['text_footer']        = 'Siparişiniz ile ilgili bir sorunuz varsa bu e-postayı cevaplayınız.';