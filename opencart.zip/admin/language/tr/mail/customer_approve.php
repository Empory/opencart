<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_subject']  = '%s - Hesabınız Etkinleştirildi!';
$_['text_welcome']  = '%s sitemize kayıt olduğunuz için teşekkür ederiz!';
$_['text_login']    = 'Hesabınız onaylanmıştır. Aşağıdaki adres üzerinden, sitemize kayıtlı e-posta ve şifrenizi kullanarak giriş yapabilirsiniz:';
$_['text_service']  = 'Giriş yaptıktan sonra, hesap bilgilerinizi düzenleyebilir veya geçmiş siparişlerinizi inceleyebilirsiniz';
$_['text_thanks']   = 'Teşekkürler,';

// Button
$_['button_login']  = 'Oturum Aç';