<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_subject']   = '%s - GDPR İsteğiniz Reddedildi!';
$_['text_export']    = 'Hesap Dışa Aktarma İsteği';
$_['text_remove']    = 'Hesap Silme İsteği';
$_['text_hello']     = 'Merhaba <strong>%s</strong>,';
$_['text_user']      = 'Kullanıcı';
$_['text_contact']   = 'Maalesef isteğiniz reddedildi. Daha fazla bilgi için buradan mağazaya ulaşabilirsiniz:';
$_['text_thanks']    = 'Teşekkürler,';

// Button
$_['button_contact'] = 'İletişime Geçin';