<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_success']  = 'Başarılı: Hediye çeki başarılı bir şekilde değiştirildi!';
$_['text_subject']  = '%s tarafından hediye çeki gönderildi!';
$_['text_greeting'] = 'Tebrikler, %s değerinde bir hediye çeki aldınız';
$_['text_from']     = 'Bu hediye çeki %s tarafından gönderildi';
$_['text_message']  = 'Birde mesajınız var';
$_['text_redeem']   = 'Hediye çekini <b>%s</b> kodu ile kullanabilirsiniz. Aşağıdaki bağlantıdaki web sitesine giderek istediğiniz ürünü sepete ekleyiniz ve kasaya gitmenden önce alışveriş sepeti sayfasında size gönderilen hediye çeki kodu girerek kullanabilirsiniz.';
$_['text_footer']   = 'Lütfen herhangi bir sorunuz varsa bu e-posta adresini yanıtlayınız.';
$_['text_sent']     = 'Başarılı: Hediye çeki e-postası gönderildi!';