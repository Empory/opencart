<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_subject']  = '%s - Hesap Bakiyeniz';
$_['text_received'] = '%s kredi aldınız!';
$_['text_total']    = 'Kazandığınız krediyle birlikte toplam krediniz %s.';
$_['text_credit']   = 'Kazandığınız krediler sonraki alışverişinizde hesabınızdan otomatik olarak düşülür.';