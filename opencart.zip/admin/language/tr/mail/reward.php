<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_subject']  = '%s - Puan';
$_['text_received'] = '%s Puan Kazandınız!';
$_['text_total']    = 'Şu anki toplam puanınız %s.';