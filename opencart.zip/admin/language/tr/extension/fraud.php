<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title']    = 'Sahtekârlık Araçları';

// Text
$_['text_success']     = 'Başarılı: Sahtekârlık araçları güncellendi!';
$_['text_list']        = 'Sahtekârlık Araçlar Listesi';

// Column
$_['column_name']      = 'Araç Adı';
$_['column_status']    = 'Durumu';
$_['column_action']    = 'Eylem';

// Error
$_['error_permission'] = 'Uyarı: Sahtekârlık araçlarını değiştirme iznine sahip değilsiniz!';
$_['error_extension']  = 'Uyarı: Eklenti mevcut değil!';