<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading Title
$_['heading_title']	= 'Tanıtım';