<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title']   = 'Erişim İzniniz Yok!';

// Text
$_['text_permission'] = 'Bu sayfaya erişim izniniz bulunmuyor. Lütfen sistem yöneticinize başvurunuz. Eğer yönetici iseniz kullanıcı gruplarından yönetici izinlerini ayarlayınız.';