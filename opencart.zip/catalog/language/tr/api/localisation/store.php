<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_success'] = 'Başarılı: Mağaza değiştirildi!';

// Error
$_['error_store']  = 'Uyarı: Mağaza bulunamadı!';