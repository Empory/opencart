<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_success']   = 'Başarılı: Para birimi değiştirildi!';

// Error
$_['error_currency'] = 'Uyarı: Para birimi bulunamadı!';