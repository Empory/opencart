<?php
// Text
$_['text_success']           = 'Başarılı: Kargo metotu ayarlandı!';

// Error
$_['error_shipping_address'] = 'Uyarı: Kargo adresi gerekli!';
$_['error_shipping_method']  = 'Uyarı: Kargo metotu gerekli!';
$_['error_no_shipping']      = 'Uyarı: Kullanılabilir kargo seçeneği yok!';
$_['error_shipping']         = 'Uyarı: Kargo gerektiren ürün bulunamadı!';
