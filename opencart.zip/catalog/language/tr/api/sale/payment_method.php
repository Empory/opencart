<?php
// Text
$_['text_success']          = 'Başarılı: Ödeme metotu ayarlandı!';

// Error
$_['error_payment_address'] = 'Uyarı: Fatura adresi gerekli!';
$_['error_payment_method']  = 'Uyarı: Ödeme metotları gerekli!';
$_['error_no_payment']      = 'Uyarı: Kullanılabilir ödeme seçeneği yok!';
$_['error_product']         = 'Uyarı: Ürünler gerekli!';