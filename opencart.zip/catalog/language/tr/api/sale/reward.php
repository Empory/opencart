<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_success']  = 'Başarılı: Puan indirimi başarıyla uygulandı!';
$_['text_remove']   = 'Başarılı: Puan indirimi başarıyla kaldırıldı!';

// Error
$_['error_reward']  = 'Uyarı: Lütfen kullanmak istediğiniz puanı giriniz!';
$_['error_points']  = 'Uyarı: %s puanınız yok!';
$_['error_maximum'] = 'Uyarı: Kullanbileceğiniz en yüksek puan %s!';
