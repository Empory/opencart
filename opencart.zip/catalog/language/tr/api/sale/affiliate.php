<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_success']    = 'Başarılı: Bu siparişe bağlı ortak komisyonu uygulanacaktır!';
$_['text_remove']     = 'Başarılı: Ortak komisyonu kaldırıldı!';

// Error
$_['error_affiliate'] = 'Uyarı: Ortak bulunamadı!';