<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_success'] = 'Başarılı: İndirim kuponu septinize başarıyla uygulandı!';
$_['text_remove']  = 'Başarılı: Kupon indiriminiz kaldırıldı!';

// Error
$_['error_coupon'] = 'Uyarı: Kupon kodunuz geçersiz, süresi ya da kullanım limiti dolmuş!';