<?php
// Text
$_['text_success']     = 'Başarılı: API oturumu başarıyla başlatıldı!';

// Error
$_['error_permission'] = 'Uyarı: API erişim iznine sahip değilsiniz!';
$_['error_key']        = 'Uyarı: API anahtarı yanlış!';
$_['error_ip']         = 'Uyarı: %s IP adresinden API erişimine izin verilmiyor!';