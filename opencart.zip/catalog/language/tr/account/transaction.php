<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title']      = 'Bakiye İşlemlerim';

// Column
$_['column_date_added']  = 'Ekleme Tarihi';
$_['column_description'] = 'Açıklama';
$_['column_amount']      = 'Tutar (%s)';

// Text
$_['text_account']       = 'Hesabım';
$_['text_transaction']   = 'Bakiye İşlemlerim';
$_['text_total']         = 'Geçerli bakiyeniz:';
$_['text_no_results']    = 'Herhangi bir işleminiz yok!';