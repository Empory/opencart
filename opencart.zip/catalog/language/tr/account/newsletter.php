<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title']    = 'Bülten Aboneliği';

// Text
$_['text_account']     = 'Hesabım';
$_['text_newsletter']  = 'Bülten Aboneliği';
$_['text_success']     = 'Başarılı: Bülten aboneliğiniz başarılı bir şekilde güncellendi!';

// Entry
$_['entry_newsletter'] = 'Abonelik';