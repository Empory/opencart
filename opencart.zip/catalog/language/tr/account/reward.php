<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title']      = 'Puanlarım';

// Column
$_['column_date_added']  = 'Ekleme Tarihi';
$_['column_description'] = 'Açıklama';
$_['column_points']      = 'Puan';

// Text
$_['text_account']       = 'Hesabım';
$_['text_reward']        = 'Puanlarım';
$_['text_total']         = 'Toplam puanınız:';
$_['text_no_results']    = 'Hiç puanınız yok!';