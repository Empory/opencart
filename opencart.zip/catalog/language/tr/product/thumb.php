<?php
// Text
$_['text_price'] = 'Fiyatı:';
$_['text_tax']   = 'Vergisiz:';