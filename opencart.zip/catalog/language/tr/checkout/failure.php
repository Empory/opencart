<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title'] = 'Ödeme Başarısız!';

// Text
$_['text_basket']   = 'Alışveriş Sepetim';
$_['text_checkout'] = 'Kasaya Git';
$_['text_failure']  = 'Ödeme Başarısız';
$_['text_message']  = '<p>Ödeme işlemi sırasında bir sorun oluştu ve siparişiniz tamamlanamadı.</p>

<p>Olası nedenler:</p>
<ul>
  <li>Yetersiz bakiye</li>
  <li>Doğrulama başarısız</li>
</ul>

<p>Lütfen başka bir ödeme yöntemi kullanarak yeniden sipariş vermeyi deneyin.</p>

<p>Eğer sorun devam ederse, lütfen <a href="%s">iletişim sayfasından</a> sipariş detaylarınız ile birlikte bizimle irtibata geçiniz.</p>
';