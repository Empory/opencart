<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title']          = 'Kargo Metotu';

// Text
$_['text_success']           = 'Başarılı: Kargo metotu değiştirildi!';

// Error
$_['error_shipping_address'] = 'Uyarı: Kargo adresi gerekli!';
$_['error_shipping_method']  = 'Uyarı: Kargo metotu gerekli!';
$_['error_no_shipping']      = 'Uyarı: Kargo metotu mevcut değil. Lütfen <a href="%s">iletişim</a> için bize ulaşın!';
