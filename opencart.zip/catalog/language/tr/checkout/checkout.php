<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title'] = 'Kasaya Git';

// Text
$_['text_cart']     = 'Alışveriş Sepetim';