<?php
// Text
$_['text_subject']      = '%s - Sipariş %s';
$_['text_received']     = 'Siparişiniz var.';
$_['text_order_id']     = 'Sipariş No:';
$_['text_date_added']   = 'Sipariş Detayları:';
$_['text_order_status'] = 'Sipariş Durumu:';
$_['text_product']      = 'Ürünler:';
$_['text_total']        = 'Toplamlar:';
$_['text_comment']      = 'Siparişiniz ile ilgili açıklamalar:';