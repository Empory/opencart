<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_subject']  = '%s - Ürüne Yorum Yapıldı';
$_['text_waiting']  = 'Onay bekleyen yeni bir ürün yorumu var.';
$_['text_product']  = 'Ürün:';
$_['text_reviewer'] = 'Yorum Yapan:';
$_['text_rating']   = 'Verilen Oy:';
$_['text_review']   = 'Yorum:';