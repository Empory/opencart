<?php
// Text
$_['text_all'] = 'Tümünü Göster';