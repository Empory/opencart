<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Heading
$_['heading_title']    = 'Bakım Modu';

// Text
$_['text_maintenance'] = 'Bakım Modu';
$_['text_message']     = '<h1 style="text-align:center;">Mağazamızda güncelleme çalışması yapılmaktadır.<br/>Çalışmalarımızı en kısa sürede tamamlayıp geri döneceğiz.<br/>Lüften daha sonra tekrar kontrol ediniz.</h1>';