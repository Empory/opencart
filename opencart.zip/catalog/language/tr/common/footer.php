<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_information']  = 'Bilgiler';
$_['text_service']      = 'Müşteri Servisi';
$_['text_extra']        = 'Ekstralar';
$_['text_contact']      = 'İletişim';
$_['text_return']       = 'Ürün İadesi';
$_['text_sitemap']      = 'Site Haritası';
$_['text_gdpr']         = 'KVKK İstekleri';
$_['text_manufacturer'] = 'Markalar';
$_['text_voucher']      = 'Hediye Çeki';
$_['text_affiliate']    = 'Ortaklık Programı';
$_['text_special']      = 'Kampanyalar';
$_['text_account']      = 'Hesabım';
$_['text_order']        = 'Siparişlerim';
$_['text_wishlist']     = 'Alışveriş Listem';
$_['text_newsletter']   = 'Bülten Aboneliği';
$_['text_powered']      = '%s &copy; %s - Tüm Hakları Saklıdır.<br />Altyapı: <a href="https://www.opencart.com" title="OpenCart">OpenCart</a> - Türkçe Çeviri: <a href="https://e-piksel.com" title="E-Piksel E-Ticaret ve Bilgi Teknolojileri">E-Piksel</a>';