<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_success'] = 'Seçiminizi bize bildirdiğiniz için teşekkür ederiz!';
$_['text_cookie']  = 'Bu web sitesi çerezleri kullanır. Daha fazla bilgi için <a href="%s" class="alert-link modal-link">burayı tıklayın</a>.';

// Button
$_['button_agree']    = 'Kabul Ediyorum!';
$_['button_disagree'] = 'Etmiyorum!';