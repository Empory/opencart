<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_currency'] = 'Para Birimi';