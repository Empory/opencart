<?php
// Heading
$_['heading_title'] = 'KVKK Başarılı';

// Text
$_['text_account']  = 'Hesabım';
$_['text_export']   = 'Hesap verilerinizi dışa aktarma isteği alındı.';
$_['text_remove']   = 'Hesap silme istekleri, herhangi bir sahtekarlık tespiti, ters ibrazlar veya geri ödeme işlemeleri için <strong>%s günden</strong> sonra işlenecektir.';
