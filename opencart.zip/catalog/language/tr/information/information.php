<?php
// Translator : Ekrem KAYA
// Website    : https://e-piksel.com

// Text
$_['text_error'] = 'Bilgi Sayfası Bulunamadı!';